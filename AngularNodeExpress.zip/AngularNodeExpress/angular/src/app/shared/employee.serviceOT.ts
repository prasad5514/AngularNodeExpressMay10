import { Injectable } from '@angular/core';
import { EmployeeC } from 'src/app/shared/employee.modelFi'
import { HttpClient } from "@angular/common/http";

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {

  formData2 : EmployeeC;
  list2 : EmployeeC[];
  readonly rootURL2 ="https://dev.digisuvidhacentre.com/Profile/api/MockUser"

  constructor(private http : HttpClient) { }

    postEmployee(formData2: EmployeeC){
    return this.http.post(this.rootURL2,formData2)

  // return this.http.post(this.rootURL2,{"UserName": "Demo user",
  //   "Email": "demomail@mail.com",
  //   "Phone": "1234567890",
  //   "Gender": "M",
  //   "Age": 28
  //  })
    
  }
  // postEmployee2(formData2: EmployeeC){
  //   return this.http.post(this.rootURL2,formData2)
  //   .subscribe((data4)=>{console.log(data4)})
  // }

  refreshList(){
    //this.http.get(this.rootURL2)
    this.http.get("https://dev.digisuvidhacentre.com/Profile/api/MockUser")
    .toPromise().then(res => this.list2 = res as EmployeeC[]);
    //return this.http.get("https://dev.digisuvidhacentre.com/Profile/api/MockUser")
    //return this.http.get(this.rootURL2);
  }

  refreshList3(){
    //return this.http.get("http://localhost:3001/employees")
    return this.http.get("https://dev.digisuvidhacentre.com/Profile/api/MockUser")
  }
  deleteEmployeeT(id : number){
    // return this.http.delete(this.rootURL2+'/EmployeeC/'+id);
    // return this.http.delete(this.rootURL2+'/Delete/'+_id);
    //return this.http.delete("http://localhost:3001/employees"+`/${_id}`);
    return this.http.delete(this.rootURL2+'/Delete/'+id);
    //console.log(id)
   }
   postEmployee2(item3){
      //return this.http.post("http://localhost:3001/employees",{"employee2":item3})
      return this.http.get("https://dev.digisuvidhacentre.com/Profile/api/MockUser",item3)
      .subscribe((data2)=>{console.log(data2)})
    }

   deleteEmployee(id : number){
    // return this.http.delete(this.rootURL2+'/EmployeeC/'+id);
    return this.http.delete(this.rootURL2+'/Delete/'+id);
   }

}
