// //this file is to connect db with server
// const mongoose=require("mongoose");  //accessing package 

// mongoose.connect('mongodb://localhost:27017/ProductDb'); //database connction,ProductDb is name of db that going to makes,mongoose is middleware

// //mongoose.connect('mongodb://localhost:27017/library', { useNewUrlParser: true }); //from net half error gone


// const Schema=mongoose.Schema;     
//     var NewProductSchema=new Schema({
//         productId:Number,
//         productName:String,
//         productCode:String,
//         releaseDate:String,
//         description:String,
//         price:Number,
//         starRating:Number,
//         imageUrl:String
//     });
// //construter

// //model creation,need to embed this schema inside a model,each and every model will be intance of document or each instance model will be document 
// var Productdata=mongoose.model("pro-col",NewProductSchema); //(collection name)bookdata will become bookdata in db
// //the data is passed from the adminroutes to the database viabookdatae,bookdatae is the link for the database
// module.exports=Productdata;

const mongoose=require("mongoose");
//mongoose.connect('mongodb://localhost:27017/EmployeeDb');
mongoose.connect('mongodb://localhost/EmployeeDb', {useNewUrlParser: true, useUnifiedTopology: true});

const Schema=mongoose.Schema;
var NewEmployeeSchema=new Schema({
    userName:String,
    email:String,
    phone:String,
    gender:String,
    age:Number
});

var empModel2=mongoose.model("empCol",NewEmployeeSchema);
module.exports=empModel2;