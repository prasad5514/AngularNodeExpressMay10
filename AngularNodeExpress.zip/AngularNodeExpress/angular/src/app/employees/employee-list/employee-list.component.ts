import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { EmployeeService } from 'src/app/shared/employee.service';
import { EmployeeC } from 'src/app/shared/employee.modelFi'
import { ToastrService } from 'ngx-toastr';
import { JsonPipe } from '@angular/common';
declare var M: any;

@Component({
  selector: 'app-employee-list',
  templateUrl: './employee-list.component.html',
  styleUrls: ['./employee-list.component.css']
})
export class EmployeeListComponent implements OnInit {

  constructor(private service: EmployeeService,
    private toastr: ToastrService) { }
    list3:EmployeeC[];
    list:EmployeeC;

  ngOnInit() {
    //this.service.refreshList();
    this.refreshList0();
    // this.service.refreshList3().subscribe((data3)=>{
    //   this.list3=JSON.parse(JSON.stringify(data3))
    // })
  }
  refreshList0(){
    // this.service.refreshList().subscribe((data3)=>{
    //   this.list3=JSON.parse(JSON.stringify(data3))
    // })
    this.service.refreshList2();
  }
  onEdit(emp: EmployeeC) {
    // this.employeeService.selectedEmployee = emp;
    this.service.formData2 = emp;
  }
 

  populateForm(emp: EmployeeC) {
    this.service.formData2 = Object.assign({}, emp);
    
    // if(form.value._id!=""){
    //   this.service.postEmployee(form.value).subscribe((res)=>{
    //     this.refreshList0();
    //     this.toastr.warning('Updated successfully', 'EMP1. Register');
    //   })
    // } 
    //this.list=JSON.parse(JSON.stringify(this.service.formData2))

    console.log(this.service.formData2)
    this.toastr.warning(this.service.formData2.phone,this.service.formData2.gender);
    // this.toastr.warning(this.service.formData2.email,this.service.formData2.userName);
    //alert(this.service.formData2.age);
    //this.toastr.warning(this.list.userName);
    //M.toast({ html: 'Deleted successfully', classes: 'rounded' });
    //M.toast({ html: '<ol><li>'+this.list.userName+'</li><li>'+this.list.email+'</li><li>'+this.list.phone+'</li><li>'+this.list.gender+'</li><li>'+this.list.age+'</li></ol>', classes: 'rounded' });
    //alert("<h1>hello</h1>")
    //EmpModV=this.service.formData2;
    // if (confirm(this.service.formData2.email)){
    //   alert("hello")
    // }
  }

  // onDelete(_id: string, form: NgForm) {
    // onDelete(id: number, form:NgForm) {
      onDelete(_id: string) {
    if (confirm('Are you sure to delete this record?')) {
      this.service.deleteEmployee(_id).subscribe((res) => {
        // this.service.deleteEmployee(id).subscribe(res => {
        //this.service.refreshList();   //wont give proper result
        this.refreshList0();
        //form.reset();
        this.toastr.warning('Deleted successfully', 'EMP1. Register');
        console.log(_id)
        //M.toast({ html: 'Deleted successfully', classes: 'rounded' });
      });
    }
  }


}
